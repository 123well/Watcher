# Watcher

Основано на [123well/Watcher](https://github.com/123well/Watcher), исходный коммит `d706df2ed2ca68509e672f2d786364345f0dda47`. Этот репозиторий содержит самостоятельную копию с изменениями; GitHub-fork не создавался.

Локальный Qt6/QML-оверлей и RAG для Linux. Требования проекта находятся в [Тз.txt](Тз.txt).

**Текущее состояние этой ветки: стабилизация RAG, подключение поиска к чату и настройка локального OpenAI-совместимого сервера. Полное ТЗ ещё не реализовано.** Подробный статус: [docs/implementation-status.md](docs/implementation-status.md).

## Сборка

Нужны C++20, CMake ≥ 3.20, Qt6 Core/Gui/Quick/Qml/Network, SQLite с FTS5 и nlohmann-json. Для запуска нужны QML-модули QtQuick, QtQuick.Window и QtQml.WorkerScript. Для оверлея в Plasma Wayland требуется установленная интеграция layer-shell Qt.

Пример зависимостей на Ubuntu 24.04 (для сборки и тестов):

```sh
sudo apt-get install cmake ninja-build qt6-base-dev qt6-declarative-dev libsqlite3-dev nlohmann-json3-dev qml6-module-qtquick qml6-module-qtquick-window qml6-module-qtqml-workerscript
cmake -S . -B build -G Ninja -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
```

`watcher` — графический оверлей; `rag-cli --help` — операции с базой. Существующая база по умолчанию остаётся в `~/.local/share/watcher/rag.db` (или `$XDG_DATA_HOME/watcher/rag.db`). Настройки сохраняются через QSettings локально.

## Настройка

В оверлее слева снизу доступны RAG и настройки. Адрес модели, порт, точный идентификатор модели чата, контекст, режим размышления и пути RAG применяются без перекомпиляции. Менять настройки следует после завершения текущих задач.

Сервер чата должен слушать loopback и предоставлять `/v1/chat/completions` с SSE и tool calling; обнаружение проверяет `/v1/models`. Разрешены только `127.0.0.1`, `localhost`, `::1`; перенаправления не выполняются. Проверка `/v1/models` подтверждает доступность API, а не производителя GPU, качество генерации или поддержку конкретной модели.

Профили:

- `amd`: существующий сервер, стандартный порт 52625;
- `intel-openvino`: отдельно запущенный OpenVINO Model Server, типовой порт 8000;
- `intel-sycl`: отдельно запущенный `llama-server` с SYCL, типовой порт 8080.

Профиль не устанавливает сервер, драйверы, веса или поддержку архитектуры модели. Для переключения укажи фактический порт и точное имя из `/v1/models`. Настройка контекста ограничивает запрос со стороны клиента консервативной оценкой по UTF-8-байтам; соответствующий контекст должен быть настроен и на сервере.

Официальные инструкции: [OpenVINO Model Server](https://docs.openvino.ai/2026/model-server/ovms_what_is_openvino_model_server.html), [llama.cpp SYCL](https://github.com/ggml-org/llama.cpp/blob/master/docs/backend/SYCL.md), [llama.cpp server](https://github.com/ggml-org/llama.cpp/tree/master/tools/server). Совместимость Qwen3.8-27B, спекуляции и конкретного Intel NPU требует отдельной проверки; она не следует из наличия OpenAI-совместимого HTTP API.

Эмбеддинги независимы от профиля чата. Нужны бинарник `llama-server` и bge-m3 GGUF:

```sh
export WATCHER_LLAMA_SERVER=/absolute/path/to/llama-server
export WATCHER_RAG_MODEL=/absolute/path/to/bge-m3-q8_0.gguf
export WATCHER_RAG_DB=/absolute/path/to/rag.db
./build/watcher
```

Переменные задают первоначальные значения; сохранённые настройки имеют приоритет. Для эмбеддингов принудительно задано `-ngl 0`, pooling `cls`, окно 8192. Просмотр базы и изменение тегов доступны без загруженной модели. Добавление, редактирование текста/заголовка и поиск требуют модели. При изменении модели эмбеддингов используй отдельную базу или переиндексацию; смешивать векторы разных моделей нельзя.

## Проверки и ограничения

Три набора CTest проверяют RAG с тестовым провайдером, реальный HTTP/SSE-транспорт с локальным тестовым сервером, сохранение настроек, асинхронный поиск, загрузку QML и корректное завершение потоков. Реальные веса и GPU в CI не используются. Offscreen-проверка не проверяет хоткеи, layer-shell и поведение KWin.

Фильтр перед записью RAG отклоняет типовые ключи, токены, пароли, email и некоторые персональные идентификаторы. Это эвристика, не гарантия распознавания произвольной конфиденциальной информации. Не загружай в базу секреты. Другие хранилища из ТЗ пока не созданы.
