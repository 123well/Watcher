#include "app_settings.h"
#include "security/privacy_filter.h"
#include <QStandardPaths>
#include <QDir>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QUrl>
#include <QTimer>

AppSettings::AppSettings(QObject *parent) : QObject(parent)
{
    // Keep the existing installation's ~/.local/share/watcher/rag.db by default.
    const QString data = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation) + "/watcher";
    m_values = {{"backend", "amd"}, {"host", "127.0.0.1"}, {"port", 52625},
        {"activeModel", "qwen3:8b"}, {"reflectionModel", "Qwen3.8-27B"},
        {"activeContext", 16384}, {"reflectionContext", 4096}, {"thinking", false},
        {"ragDatabase", qEnvironmentVariable("WATCHER_RAG_DB", data + "/rag.db")},
        {"embeddingServer", qEnvironmentVariable("WATCHER_LLAMA_SERVER", "llama-server")},
        {"embeddingModel", qEnvironmentVariable("WATCHER_RAG_MODEL", QDir::homePath() + "/models/bge-m3-q8_0.gguf")}};
    QVariantMap loaded = m_values;
    for (auto it = loaded.begin(); it != loaded.end(); ++it)
        it.value() = m_store.value(it.key(), it.value());
    apply(loaded);
}

bool AppSettings::apply(const QVariantMap &values)
{
    QVariantMap next = m_values;
    for (auto it = values.begin(); it != values.end(); ++it)
        if (next.contains(it.key())) next[it.key()] = it.value();
    auto reject = [this](const QString &error) {
        m_error = error;
        emit changed();
        return false;
    };
    const QString host = next["host"].toString().trimmed();
    if (host != "127.0.0.1" && host != "localhost" && host != "::1")
        return reject(QStringLiteral("Разрешён только локальный сервер (127.0.0.1 / localhost / ::1)."));
    const int port = next["port"].toInt();
    if (port < 1 || port > 65535) return reject(QStringLiteral("Порт должен быть от 1 до 65535."));
    if (!QStringList{"amd", "intel-openvino", "intel-sycl"}.contains(next["backend"].toString()))
        return reject(QStringLiteral("Неизвестный бэкэнд."));
    for (const QString key : {"activeModel", "reflectionModel", "ragDatabase", "embeddingServer", "embeddingModel"}) {
        const QString value = next[key].toString().trimmed();
        if (value.isEmpty() || value.contains('\n') || security::containsSensitiveData(value))
            return reject(QStringLiteral("Пустое или недопустимое значение настройки: ") + key);
        next[key] = value;
    }
    if (!QDir::isAbsolutePath(next["ragDatabase"].toString()) ||
        !QDir::isAbsolutePath(next["embeddingModel"].toString()))
        return reject(QStringLiteral("Пути базы и модели должны быть абсолютными."));
    const int active = next["activeContext"].toInt();
    const int reflection = next["reflectionContext"].toInt();
    if (active < 2048 || active > 32768 || reflection < 2048 || reflection > 8192)
        return reject(QStringLiteral("Контекст: активный 2048–32768, фоновый 2048–8192."));
    next["host"] = host;
    next["port"] = port;
    for (auto it = next.begin(); it != next.end(); ++it) m_store.setValue(it.key(), it.value());
    m_store.sync();
    if (m_store.status() != QSettings::NoError)
        return reject(QStringLiteral("Не удалось сохранить настройки."));
    m_values = next;
    m_error.clear();
    emit changed();
    return true;
}

void AppSettings::probeBackends()
{
    const int generation = ++m_probeGeneration;
    m_backends.clear();
    // Endpoint capabilities are verified, never inferred from the machine's CPU vendor.
    const QList<QPair<QString, int>> profiles = {{"amd", 52625}, {"intel-openvino", 8000}, {"intel-sycl", 8080}};
    for (const auto &profile : profiles) {
        const bool selected = profile.first == m_values["backend"].toString();
        QUrl url;
        url.setScheme("http");
        url.setHost(selected ? m_values["host"].toString() : QStringLiteral("127.0.0.1"));
        url.setPort(selected ? m_values["port"].toInt() : profile.second);
        url.setPath("/v1/models");
        QNetworkRequest request(url);
        request.setTransferTimeout(1500);
        request.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
        auto *reply = m_network.get(request);
        connect(reply, &QNetworkReply::finished, this, [this, reply, profile, generation] {
            if (generation == m_probeGeneration) {
                const QByteArray bytes = reply->readAll();
                const auto doc = QJsonDocument::fromJson(bytes.left(1024 * 1024));
                const bool available = reply->error() == QNetworkReply::NoError &&
                    reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt() == 200 &&
                    doc.isObject() && doc.object().value("data").isArray();
                QStringList models;
                if (available) for (const auto &item : doc.object().value("data").toArray())
                    models << item.toObject().value("id").toString();
                m_backends.append(QVariantMap{{"id", profile.first}, {"available", available}, {"models", models}});
                emit backendsChanged();
            }
            reply->deleteLater();
        });
    }
    emit backendsChanged();
}
