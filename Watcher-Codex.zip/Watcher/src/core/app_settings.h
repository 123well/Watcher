#pragma once
#include <QObject>
#include <QVariantMap>
#include <QSettings>
#include <QNetworkAccessManager>

class AppSettings : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantMap values READ values NOTIFY changed)
    Q_PROPERTY(QString error READ error NOTIFY changed)
    Q_PROPERTY(QVariantList backends READ backends NOTIFY backendsChanged)
public:
    explicit AppSettings(QObject *parent = nullptr);
    QVariantMap values() const { return m_values; }
    QString error() const { return m_error; }
    QVariantList backends() const { return m_backends; }
    Q_INVOKABLE bool apply(const QVariantMap &values);
    Q_INVOKABLE void probeBackends();
signals:
    void changed();
    void backendsChanged();
private:
    QSettings m_store;
    QVariantMap m_values;
    QString m_error;
    QVariantList m_backends;
    QNetworkAccessManager m_network;
    int m_probeGeneration = 0;
};
