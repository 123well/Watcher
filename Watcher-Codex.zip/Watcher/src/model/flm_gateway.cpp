#include "flm_gateway.h"
#include "sse_parser.h"
#include <iostream>
#include <QCoreApplication>
#include <QEventLoop>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QTimer>
#include <QUrl>

// --- StreamQueue ---

void StreamQueue::push(StreamEvent event) {
    std::unique_lock<std::mutex> lock(m_mutex);
    m_queue.push_back(std::move(event));
    m_cv.notify_one();
}

std::optional<StreamEvent> StreamQueue::pop_blocking(int timeout_ms) {
    std::unique_lock<std::mutex> lock(m_mutex);
    if (m_cv.wait_for(lock, std::chrono::milliseconds(timeout_ms), [this]{ return !m_queue.empty(); })) {
        StreamEvent event = std::move(m_queue.front());
        m_queue.pop_front();
        return event;
    }
    return std::nullopt;
}

// --- FlmGateway ---

FlmGateway::FlmGateway(StreamQueue& queue, const std::string& host, int port)
    : m_queue(queue), m_host(host), m_port(port) {}

FlmGateway::~FlmGateway() {
    cancelActive();
    if (m_worker.joinable()) m_worker.join();
}

bool FlmGateway::trySubmit(const LlmRequest& request) {
    std::lock_guard<std::mutex> lock(m_mutex);

    if (m_busy) {
        std::cout << "[FlmGateway] FLM is busy. Request " << request.id << " ignored.\n";
        return false;
    }

    m_busy = true;
    m_activeRequestId = request.id;
    m_cancelRequested = false;

    if (m_worker.joinable()) m_worker.join();

    m_worker = std::thread(&FlmGateway::workerMain, this, request);
    return true;
}

void FlmGateway::cancelActive() {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_busy) return;
    m_cancelRequested = true;
}

bool FlmGateway::isBusy() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_busy;
}

void FlmGateway::workerMain(LlmRequest request) {
    const std::string host = request.host.empty() ? m_host : request.host;
    const int port = request.port > 0 ? request.port : m_port;
    if ((host != "127.0.0.1" && host != "localhost" && host != "::1") || port < 1 || port > 65535) {
        finishActive();
        pushEvent(StreamEvent::Type::Error, request.id, "", "Only a local inference endpoint is allowed");
        return;
    }
    QNetworkAccessManager network;
    QUrl url;
    url.setScheme("http");
    url.setHost(QString::fromStdString(host));
    url.setPort(port);
    url.setPath("/v1/chat/completions");
    QNetworkRequest http(url);
    http.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    http.setRawHeader("Accept", "text/event-stream");
    http.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
    json body = {{"model", request.model}, {"messages", request.messages},
        {"stream", true}, {"temperature", request.temperature},
        {"max_tokens", request.maxTokens},
        {"chat_template_kwargs", {{"enable_thinking", request.thinking}}}};
    if (!request.response_format.is_null()) body["response_format"] = request.response_format;
    if (!request.tools.is_null() && !request.tools.empty()) body["tools"] = request.tools;
    auto *reply = network.post(http, QByteArray::fromStdString(body.dump()));
    std::map<int, json> calls;
    bool protocolFailed = false;
    bool finished = false;
    SseParser parser([&](const std::string &data) {
        if (data == "[DONE]") { finished = true; return; }
        if (!finished && !processSseEvent(data, request.id, calls)) {
            protocolFailed = true;
            reply->abort();
        }
    });
    QEventLoop loop;
    QTimer cancellation;
    cancellation.setInterval(25);
    QObject::connect(&cancellation, &QTimer::timeout, &loop, [&] {
        if (m_cancelRequested) reply->abort();
    });
    QTimer deadline;
    deadline.setSingleShot(true);
    bool timedOut = false;
    QObject::connect(&deadline, &QTimer::timeout, &loop, [&] {
        timedOut = true;
        reply->abort();
    });
    QObject::connect(reply, &QNetworkReply::readyRead, &loop, [&] {
        const QByteArray bytes = reply->readAll();
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (status != 200) return;
        if (!parser.feed(bytes.constData(), size_t(bytes.size()))) {
            protocolFailed = true;
            reply->abort();
        }
    });
    QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    cancellation.start();
    deadline.start(300000);
    loop.exec();
    cancellation.stop();
    deadline.stop();
    parser.finish();
    const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
    const auto error = reply->error();
    const bool cancelled = m_cancelRequested.load();
    const std::string errorText = reply->errorString().toStdString();
    delete reply;
    finishActive();
    if (cancelled) pushEvent(StreamEvent::Type::Cancelled, request.id, "", "");
    else if (timedOut) pushEvent(StreamEvent::Type::Error, request.id, "", "Inference timed out");
    else if (protocolFailed) pushEvent(StreamEvent::Type::Error, request.id, "", "Invalid or oversized SSE stream");
    else if (status != 200 || error != QNetworkReply::NoError)
        pushEvent(StreamEvent::Type::Error, request.id, "", "HTTP " + std::to_string(status) + ": " + errorText);
    else if (!finished) pushEvent(StreamEvent::Type::Error, request.id, "", "Incomplete SSE stream");
    else pushEvent(StreamEvent::Type::Done, request.id, "", "");
}

bool FlmGateway::processSseEvent(const std::string& event_str, const std::string& reqId,
                                 std::map<int, json>& tool_calls_acc) {
    const std::string &json_str = event_str;
    if (json_str == "[DONE]") return true;

    try {
        json j = json::parse(json_str);
        if (!j.is_object() || j.contains("error")) return false;

        if (j.contains("choices") && !j["choices"].empty()) {
            auto& choice = j["choices"][0];
            auto delta = choice.value("delta", json::object());

            // Reasoning (скрытые мысли)
            if (delta.contains("reasoning_content") && !delta["reasoning_content"].is_null()) {
                pushEvent(StreamEvent::Type::ReasoningToken, reqId,
                         delta["reasoning_content"].get<std::string>(), "");
            }
            // Финальный контент
            if (delta.contains("content") && !delta["content"].is_null()) {
                pushEvent(StreamEvent::Type::Token, reqId,
                         delta["content"].get<std::string>(), "");
            }

            // Tool Calls (инкрементальная сборка)
            if (delta.contains("tool_calls") && !delta["tool_calls"].is_null()) {
                auto& tool_calls = delta["tool_calls"];

                for (auto& tc : tool_calls) {
                    int index = tc.value("index", 0);
                    if (index < 0 || index > 31) continue;

                    if (tool_calls_acc.find(index) == tool_calls_acc.end()) {
                        tool_calls_acc[index] = {
                            {"index", index},
                            {"id", tc.value("id", "")},
                            {"type", "function"},
                            {"function", {
                                {"name", ""},
                                {"arguments", ""}
                            }}
                        };
                    }

                    auto& acc = tool_calls_acc[index];
                    if (tc.contains("id") && tc["id"].is_string()) acc["id"] = tc["id"];

                    if (tc.contains("function") && tc["function"].contains("name")) {
                        acc["function"]["name"] = acc["function"]["name"].get<std::string>() +
                                                 tc["function"]["name"].get<std::string>();
                    }

                    if (tc.contains("function") && tc["function"].contains("arguments")) {
                        acc["function"]["arguments"] = acc["function"]["arguments"].get<std::string>() +
                                                       tc["function"]["arguments"].get<std::string>();
                    }

                    pushEvent(StreamEvent::Type::ToolCallDelta, reqId, "", tc.dump());
                }
            }

            // finish_reason
            if (choice.contains("finish_reason") && !choice["finish_reason"].is_null()) {
                std::string reason = choice["finish_reason"].get<std::string>();

                if (reason == "tool_calls" || reason == "stop") {
                    for (auto& [idx, tc] : tool_calls_acc) {
                        pushEvent(StreamEvent::Type::ToolCall, reqId, "", tc.dump());
                    }
                    tool_calls_acc.clear();
                }
            }
        }

        // Метрики
        if (j.contains("usage") && !j["usage"].is_null()) {
            pushEvent(StreamEvent::Type::Metrics, reqId, "", j["usage"].dump());
        }

    } catch (const std::exception&) {
        return false;
    }
    return true;
}

void FlmGateway::pushEvent(StreamEvent::Type type, const std::string& reqId,
                           const std::string& text, const std::string& payload) {
    StreamEvent ev;
    ev.type = type;
    ev.requestId = reqId;
    ev.text = text;
    ev.payload = payload;
    m_queue.push(std::move(ev));
}

void FlmGateway::finishActive() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_busy = false;
    m_activeRequestId.clear();
}
