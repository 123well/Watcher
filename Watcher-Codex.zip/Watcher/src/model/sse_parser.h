#pragma once
#include <string>
#include <functional>

// Incremental SSE framing; survives CRLF and UTF-8 split across TCP packets.
class SseParser {
public:
    using Handler = std::function<void(const std::string &)>;
    explicit SseParser(Handler handler) : m_handler(std::move(handler)) {}
    bool feed(const char *data, size_t size) {
        m_line.append(data, size);
        size_t pos;
        while ((pos = m_line.find('\n')) != std::string::npos) {
            std::string line = m_line.substr(0, pos);
            m_line.erase(0, pos + 1);
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty()) dispatch();
            else if (line.rfind("data:", 0) == 0) {
                size_t start = line.size() > 5 && line[5] == ' ' ? 6 : 5;
                if (!m_data.empty()) m_data += '\n';
                m_data += line.substr(start);
            }
            if (m_data.size() > kLimit) return false;
        }
        return m_line.size() <= kLimit;
    }
    void finish() { dispatch(); }
private:
    void dispatch() {
        if (!m_data.empty()) m_handler(m_data);
        m_data.clear();
    }
    static constexpr size_t kLimit = 4 * 1024 * 1024;
    Handler m_handler;
    std::string m_line, m_data;
};
