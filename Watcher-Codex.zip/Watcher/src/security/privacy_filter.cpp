#include "privacy_filter.h"
#include <QRegularExpression>

bool security::containsSensitiveData(const QString &text)
{
    static const QRegularExpression patterns[] = {
        QRegularExpression(QStringLiteral("-----BEGIN [A-Z ]*PRIVATE KEY-----")),
        QRegularExpression(QStringLiteral(R"(\b(?:gh[pousr]_[A-Za-z0-9_]{16,}|github_pat_[A-Za-z0-9_]+|sk-[A-Za-z0-9_-]{16,}|AKIA[A-Z0-9]{16})\b)")),
        QRegularExpression(QStringLiteral(R"(\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b)")),
        QRegularExpression(QStringLiteral(R"((?:password|passwd|pwd|secret|token|api[_ -]?key|authorization|пароль|токен|секрет|ключ\s+api)\s*["']?\s*[:=]\s*\S+)"), QRegularExpression::CaseInsensitiveOption),
        QRegularExpression(QStringLiteral(R"(\bBearer\s+\S+)"), QRegularExpression::CaseInsensitiveOption),
        QRegularExpression(QStringLiteral(R"(\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b)"), QRegularExpression::CaseInsensitiveOption),
        QRegularExpression(QStringLiteral(R"((?:\+\d[\d ()-]{8,}\d|\b\d{3}-\d{3}-\d{3}\s?\d{2}\b|\b(?:\d[ -]?){16}\b))")),
        QRegularExpression(QStringLiteral(R"((?:passport|паспорт|diagnosis|диагноз|medical record|home address|домашний адрес)\s*[:=]\s*\S+)"), QRegularExpression::CaseInsensitiveOption)
    };
    for (const auto &pattern : patterns)
        if (pattern.match(text).hasMatch()) return true;
    return false;
}
