#pragma once
#include <QString>

namespace security {
// Reject the whole record: partial redaction can leave a usable credential behind.
// A deterministic heuristic, not a guarantee that arbitrary private prose is detectable.
bool containsSensitiveData(const QString &text);
}
