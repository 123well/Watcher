import QtQuick

Item {
    id: root
    property bool expanded: false
    function load() {
        var v = appSettings.values
        backend.value = v.backend
        host.value = v.host
        port.value = String(v.port)
        activeModel.value = v.activeModel
        reflectionModel.value = v.reflectionModel
        activeContext.value = String(v.activeContext)
        reflectionContext.value = String(v.reflectionContext)
        database.value = v.ragDatabase
        server.value = v.embeddingServer
        model.value = v.embeddingModel
        thinking.enabledValue = v.thinking
    }
    Button {
        anchors.left: parent.left; anchors.leftMargin: 90
        anchors.bottom: parent.bottom; anchors.bottomMargin: 22
        width: 112; height: 44; label: "Настройки"
        onClicked: { root.expanded = !root.expanded; if (root.expanded) root.load() }
    }
    Rectangle {
        visible: root.expanded
        anchors.left: parent.left; anchors.leftMargin: 22
        anchors.top: parent.top; anchors.topMargin: 22
        anchors.bottom: parent.bottom; anchors.bottomMargin: 82
        width: Math.min(500, root.width - 44)
        radius: 18; color: "#ed101c25"; border.color: "#55c6c2"; border.width: 1
        Flickable {
            anchors.fill: parent; anchors.margins: 18
            clip: true; contentHeight: form.height
            Column {
                id: form; width: parent.width; spacing: 10
                Text { text: "Локальные модели и хранилище"; color: "#a3efdc"; font.pixelSize: 18 }
                Text { width: parent.width; wrapMode: Text.Wrap; color: "#c9d2dc"
                    text: "AMD — текущий сервер. Intel — совместимый сервер OpenVINO или SYCL, запущенный отдельно. Название профиля не устанавливает сервер и не подтверждает поддержку модели." }
                Field { id: backend; label: "Профиль: amd / intel-openvino / intel-sycl" }
                Field { id: host; label: "Адрес локального сервера" }
                Field { id: port; label: "Порт" }
                Field { id: activeModel; label: "Модель чата (точный id сервера)" }
                Field { id: reflectionModel; label: "Модель рефлексии (точный id сервера)" }
                Field { id: activeContext; label: "Контекст чата (2048–32768)" }
                Field { id: reflectionContext; label: "Контекст рефлексии (2048–8192)" }
                Button {
                    id: thinking; property bool enabledValue: false
                    width: parent.width; height: 34
                    label: "Размышление чата: " + (enabledValue ? "вкл" : "выкл")
                    onClicked: enabledValue = !enabledValue
                }
                Field { id: database; label: "База RAG (абсолютный путь)" }
                Field { id: server; label: "Исполняемый файл llama-server" }
                Field { id: model; label: "Модель эмбеддингов bge-m3 (абсолютный путь)" }
                Text { width: parent.width; wrapMode: Text.Wrap; color: "#e6c875"
                    text: "Смена пути базы открывает другую базу. При смене модели эмбеддингов используй новую базу или rag-cli reindex. Размер контекста сервера должен соответствовать настройке." }
                Text { width: parent.width; wrapMode: Text.Wrap; color: "#ff8e99"; text: appSettings.error }
                Button {
                    width: parent.width; height: 40
                    enabled: !chatEngine.thinking && !rag.busy
                    label: enabled ? "Сохранить и применить" : "Дождись завершения текущих задач"
                    onClicked: {
                        if (appSettings.apply({backend: backend.value, host: host.value, port: Number(port.value),
                            activeModel: activeModel.value, reflectionModel: reflectionModel.value,
                            activeContext: Number(activeContext.value), reflectionContext: Number(reflectionContext.value),
                            ragDatabase: database.value, embeddingServer: server.value, embeddingModel: model.value,
                            thinking: thinking.enabledValue})) appSettings.probeBackends()
                    }
                }
                Button { width: parent.width; height: 34; label: "Проверить локальные серверы"; onClicked: appSettings.probeBackends() }
                Repeater {
                    model: appSettings.backends
                    delegate: Text {
                        required property var modelData
                        width: form.width; wrapMode: Text.Wrap
                        color: modelData.available ? "#8eebbb" : "#a0a9b8"
                        text: modelData.id + ": " + (modelData.available ? "доступен · " + modelData.models.join(", ") : "не обнаружен")
                    }
                }
                Button { width: parent.width; height: 34; label: "Закрыть"; onClicked: root.expanded = false }
            }
        }
    }
    component Field: Column {
        property alias value: input.text
        property string label
        width: form.width; spacing: 3
        Text { text: parent.label; color: "#becbd5"; font.pixelSize: 11 }
        Rectangle {
            width: parent.width; height: 34; radius: 8; color: "#a5081018"
            border.color: input.activeFocus ? "#81e0ce" : "#44616a"
            TextInput { id: input; anchors.fill: parent; anchors.margins: 8
                color: "#edf4f5"; selectByMouse: true; clip: true; font.pixelSize: 12 }
        }
    }
    component Button: Rectangle {
        id: button; property string label; signal clicked
        radius: 9; color: mouse.containsMouse ? "#40666b" : "#243f49"
        border.color: "#558a8c"; opacity: enabled ? 1 : 0.5
        Text { anchors.centerIn: parent; text: button.label; color: "#e3f7f4"; font.pixelSize: 12 }
        MouseArea { id: mouse; anchors.fill: parent; hoverEnabled: true
            cursorShape: Qt.PointingHandCursor; onClicked: button.clicked() }
    }
}
