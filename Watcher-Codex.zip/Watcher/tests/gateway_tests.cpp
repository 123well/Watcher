#include "model/flm_gateway.h"
#include "model/sse_parser.h"
#include <QCoreApplication>
#include <QTcpServer>
#include <QTcpSocket>
#include <QElapsedTimer>
#include <QThread>
#include <QTimer>
#include <iostream>
#include <stdexcept>

static void require(bool condition, const char *message) { if (!condition) throw std::runtime_error(message); }
struct FakeServer : QTcpServer {
    QByteArray response;
    json request;
    bool hold = false;
    FakeServer() {
        require(listen(QHostAddress::LocalHost, 0), "listen");
        connect(this, &QTcpServer::newConnection, this, [this] {
            auto *socket = nextPendingConnection();
            auto buffer = std::make_shared<QByteArray>();
            connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
            connect(socket, &QTcpSocket::readyRead, socket, [this, socket, buffer] {
                buffer->append(socket->readAll());
                const int split = buffer->indexOf("\r\n\r\n");
                if (split < 0) return;
                int length = -1;
                for (const auto &line : buffer->left(split).split('\n')) {
                    if (line.toLower().startsWith("content-length:")) length = line.mid(15).trimmed().toInt();
                }
                if (length < 0 || buffer->size() < split + 4 + length) return;
                request = json::parse(buffer->mid(split + 4, length).toStdString());
                if (hold) return;
                socket->write("HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nConnection: close\r\n\r\n");
                // Deliberately split every byte, including CRLF and Cyrillic UTF-8.
                auto payload = std::make_shared<QByteArray>(response);
                auto *timer = new QTimer(socket);
                timer->setInterval(1);
                connect(timer, &QTimer::timeout, socket, [socket, timer, payload] {
                    if (payload->isEmpty()) { timer->stop(); socket->disconnectFromHost(); return; }
                    socket->write(payload->left(1));
                    payload->remove(0, 1);
                });
                timer->start();
                disconnect(socket, &QTcpSocket::readyRead, socket, nullptr);
            });
        });
    }
};
static std::vector<StreamEvent> waitForTerminal(StreamQueue &queue, int timeout = 6000) {
    QElapsedTimer timer; timer.start();
    std::vector<StreamEvent> events;
    while (timer.elapsed() < timeout) {
        QCoreApplication::processEvents();
        if (auto event = queue.pop_blocking(2)) {
            events.push_back(*event);
            if (event->type == StreamEvent::Type::Done || event->type == StreamEvent::Type::Error || event->type == StreamEvent::Type::Cancelled) return events;
        }
    }
    throw std::runtime_error("gateway did not terminate within deadline");
}
int main(int argc, char **argv) {
    QCoreApplication app(argc, argv);
    try {
        std::vector<std::string> messages;
        SseParser parser([&](const auto &data) { messages.push_back(data); });
        const std::string wire = ": heartbeat\r\ndata:first\r\ndata: second\r\n\r\ndata: [DONE]\n\n";
        for (char c : wire) require(parser.feed(&c, 1), "SSE rejected normal data");
        require(messages.size() == 2 && messages[0] == "first\nsecond" && messages[1] == "[DONE]", "SSE framing");
        StreamQueue queue;
        FakeServer server;
        server.response = "data: {\"choices\":[{\"delta\":{\"reasoning_content\":\"r\",\"content\":\"Привет\"}}]}\r\n\r\ndata: {\"choices\":[{\"delta\":{},\"finish_reason\":\"stop\"}]}\r\n\r\ndata: [DONE]\r\n\r\n";
        FlmGateway gateway(queue, "127.0.0.1", server.serverPort());
        LlmRequest request;
        request.id = "success";
        request.model = "custom-qwen";
        request.messages = json::array({{{"role", "user"}, {"content", "hi"}}});
        require(gateway.trySubmit(request), "submit failed");
        const auto events = waitForTerminal(queue);
        std::string content, reasoning;
        for (const auto &event : events) {
            if (event.type == StreamEvent::Type::Token) content += event.text;
            if (event.type == StreamEvent::Type::ReasoningToken) reasoning += event.text;
        }
        require(events.back().type == StreamEvent::Type::Done && content == "Привет" && reasoning == "r", "stream content lost");
        require(server.request["model"] == "custom-qwen", "model setting ignored");
        server.response = "data: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"name\":\"rag_\",\"arguments\":\"{\\\"query\\\":\"}}]}}]}\n\ndata: {\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"late-id\",\"function\":{\"name\":\"search\",\"arguments\":\"\\\"test\\\"}\"}}]}}]}\n\ndata: {\"choices\":[{\"delta\":{},\"finish_reason\":\"tool_calls\"}]}\n\ndata: [DONE]\n\n";
        request.id = "tools";
        require(gateway.trySubmit(request), "tool submit failed");
        const auto tools = waitForTerminal(queue);
        int count = 0;
        for (const auto &event : tools) if (event.type == StreamEvent::Type::ToolCall) {
            const auto call = json::parse(event.payload);
            require(call["id"] == "late-id" && call["function"]["name"] == "rag_search" &&
                    json::parse(call["function"]["arguments"].get<std::string>())["query"] == "test", "tool fragments lost");
            ++count;
        }
        require(count == 1 && tools.back().type == StreamEvent::Type::Done, "tool emitted incorrectly");
        server.response = "data: {\"choices\":[{\"delta\":{\"content\":\"partial\"}}]}\n\n";
        require(gateway.trySubmit(request), "truncated submit failed");
        require(waitForTerminal(queue).back().type == StreamEvent::Type::Error, "truncated stream marked successful");
        server.hold = true;
        require(gateway.trySubmit(request), "cancel submit failed");
        QTimer::singleShot(100, &app, [&] { gateway.cancelActive(); });
        QElapsedTimer timer; timer.start();
        require(waitForTerminal(queue, 1500).back().type == StreamEvent::Type::Cancelled && timer.elapsed() < 1000, "hung request not cancelled promptly");
        request.host = "example.com";
        require(gateway.trySubmit(request), "blocked endpoint submit failed");
        require(waitForTerminal(queue).back().type == StreamEvent::Type::Error, "remote endpoint accepted");
        std::cout << "SSE framing, streaming tools, model selection, cancellation and endpoint checks passed\n";
    } catch (const std::exception &error) { std::cerr << error.what() << '\n'; return 1; }
}
