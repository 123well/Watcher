#include "rag/rag_engine.h"
#include "rag/embedding_provider.h"
#include "rag/rag_util.h"
#include "security/privacy_filter.h"
#include <QCoreApplication>
#include <QTemporaryDir>
#include <sqlite3.h>
#include <iostream>
#include <stdexcept>

static void require(bool condition, const char *message) {
    if (!condition) throw std::runtime_error(message);
}
class TestEmbedding final : public rag::EmbeddingProvider {
public:
    bool fail = false;
    bool loaded = false;
    bool invalid = false;
    int calls = 0;
    QString name() const override { return "test"; }
    QString modelId() const override { return "test-v1"; }
    int dimensions() const override { return 4; }
    int maxInputTokens() const override { return 8192; }
    rag::Pooling pooling() const override { return rag::Pooling::Cls; }
    bool isLoaded() const override { return loaded; }
    bool ensureLoaded(QString *) override { loaded = true; return true; }
    void unload() override { loaded = false; }
    std::vector<std::vector<float>> embed(const std::vector<std::string> &texts, QString *err) override {
        ++calls;
        if (fail) { if (err) *err = "injected embedding failure"; return {}; }
        std::vector<std::vector<float>> out;
        for (const auto &text : texts) {
            std::vector<float> v(4, 0.1f);
            for (unsigned char c : text) v[c % 4] += 1;
            if (invalid) v.clear();
            out.push_back(rag::normalizeVector(v));
        }
        return out;
    }
};
int main(int argc, char **argv) {
    QCoreApplication app(argc, argv);
    try {
        QTemporaryDir dir;
        require(dir.isValid(), "temporary directory");
        const QString db = dir.path() + "/nested/rag.db";
        rag::RagEngine engine;
        auto *embedding = new TestEmbedding;
        QString err;
        require(engine.init(db, embedding, &err), qPrintable(err));
        const auto first = engine.insert_data("Original", "A document about quantum physics.", rag::SourceType::Docs, "", {"old"}, {});
        require(first.ok && first.docId > 0, "insert failed");
        require(!embedding->loaded, "embedding model remains loaded after insert");
        rag::DocRecord record;
        require(engine.document(first.docId, &record), "insert not persisted");
        const auto duplicate = engine.insert_data("Original", record.text, rag::SourceType::Docs, "", {}, {});
        require(duplicate.ok && duplicate.unchanged && duplicate.docId == first.docId, "deduplication");
        const QString createdAt = record.createdAt;
        const auto title = engine.update_data(first.docId, "Renamed", record.text, {"new"});
        require(title.ok && title.docId == first.docId, "title edit changed document id");
        require(engine.document(first.docId, &record) && record.title == "Renamed", "title edit lost");
        require(record.createdAt == createdAt, "created timestamp");
        const int calls = embedding->calls;
        require(engine.update_tags(first.docId, {"metadata"}), "tags failed");
        require(embedding->calls == calls, "tag update recomputed embeddings");
        embedding->fail = true;
        const auto failure = engine.update_data(first.docId, "Lost?", "Replacement text.", {});
        require(!failure.ok, "embedding failure swallowed");
        require(!embedding->loaded, "embedding model remains loaded after failure");
        require(engine.document(first.docId, &record) && record.title == "Renamed" && record.text.contains("quantum"), "embedding failure destroyed original");
        rag::SearchQuery query;
        query.query = "quantum";
        require(!engine.rag_search(query).ok && !embedding->loaded, "search failure did not unload model");
        embedding->fail = false;
        sqlite3 *connection = nullptr;
        require(sqlite3_open(db.toUtf8().constData(), &connection) == SQLITE_OK, "open injection connection");
        require(sqlite3_exec(connection, "CREATE TRIGGER inject_failure BEFORE INSERT ON chunks BEGIN SELECT RAISE(ABORT, 'injected write failure'); END;", nullptr, nullptr, nullptr) == SQLITE_OK, "create failure trigger");
        const auto sqlFailure = engine.update_data(first.docId, "Lost?", "Replacement text.", {});
        require(!sqlFailure.ok, "SQL failure swallowed");
        require(engine.document(first.docId, &record) && record.title == "Renamed" && record.text.contains("quantum"), "SQL failure destroyed original");
        require(engine.chunk_count(first.docId) == first.chunks, "SQL rollback lost chunks");
        require(sqlite3_exec(connection, "DROP TRIGGER inject_failure;", nullptr, nullptr, nullptr) == SQLITE_OK, "drop failure trigger");
        sqlite3_close(connection);
        const auto saved = engine.update_data(first.docId, "Changed", "A document about oceanography.", {"science"});
        require(saved.ok && saved.docId == first.docId && engine.stats().documents == 1, "atomic edit failed");
        require(engine.document(first.docId, &record) && record.text.contains("oceanography"), "new text missing");
        query.query = "oceanography";
        const auto found = engine.rag_search(query);
        require(found.ok && !found.snippets.isEmpty() && !embedding->loaded, "search after replacement failed");
        query.tags = {"science"};
        require(!engine.rag_search(query).snippets.isEmpty(), "tag filter after edit failed");
        query.tags = {"absent"};
        require(engine.rag_search(query).snippets.isEmpty(), "tag filter admitted unrelated document");
        const auto sensitive = engine.insert_data("Secret", "password=do-not-save", rag::SourceType::Notes, "", {}, {});
        require(!sensitive.ok && engine.stats().documents == 1, "sensitive data stored");
        require(!engine.update_tags(first.docId, {"token=do-not-save"}), "sensitive tags stored");
        embedding->invalid = true;
        require(!engine.update_data(first.docId, "Bad", "Invalid vectors", {}).ok, "invalid vectors accepted");
        require(engine.document(first.docId, &record) && record.title == "Changed", "invalid vectors destroyed document");
        require(security::containsSensitiveData("authorization: Bearer example"), "authorization not detected");
        require(security::containsSensitiveData("person@example.com"), "email not detected");
        require(!security::containsSensitiveData("Предпочитаю короткие ответы по физике."), "ordinary preference rejected");
        require(engine.delete_data(first.docId).ok && engine.stats().documents == 0 && engine.stats().chunks == 0, "delete cascade");
        std::cout << "RAG persistence, rollback, search, privacy and resource-lifetime checks passed\n";
    } catch (const std::exception &error) { std::cerr << error.what() << '\n'; return 1; }
}
