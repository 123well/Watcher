#include "core/chat_engine.h"
#include "core/app_settings.h"
#include "rag/rag_controller.h"
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>
#include <QSettings>
#include <QStandardPaths>
#include <QTemporaryDir>
#include <QElapsedTimer>
#include <QThread>
#include <QJsonDocument>
#include <QFile>
#include <iostream>
#include <stdexcept>

static void require(bool condition, const char *message) { if (!condition) throw std::runtime_error(message); }
static bool waitUntil(const std::function<bool()> &predicate, int timeout = 3000) {
    QElapsedTimer timer; timer.start();
    while (!predicate() && timer.elapsed() < timeout) {
        QCoreApplication::processEvents();
        QThread::msleep(2);
    }
    return predicate();
}
int main(int argc, char **argv) {
    QGuiApplication app(argc, argv);
    app.setOrganizationName("WatcherTests");
    app.setApplicationName("WatcherTests");
    QStandardPaths::setTestModeEnabled(true);
    QTemporaryDir temp;
    QSettings::setDefaultFormat(QSettings::IniFormat);
    QSettings::setPath(QSettings::IniFormat, QSettings::UserScope, temp.path());
    qputenv("WATCHER_RAG_DB", (temp.path() + "/rag.db").toUtf8());
    qputenv("WATCHER_RAG_MODEL", (temp.path() + "/absent.gguf").toUtf8());
    qputenv("WATCHER_LLAMA_SERVER", (temp.path() + "/absent-server").toUtf8());
    try {
        AppSettings settings;
        const auto original = settings.values();
        require(!settings.apply({{"host", "example.com"}}), "remote server setting accepted");
        require(!settings.apply({{"port", 0}}), "invalid port accepted");
        require(!settings.apply({{"reflectionContext", 8193}}), "reflection context overflow accepted");
        require(settings.values() == original, "invalid settings clobbered configuration");
        require(settings.apply({{"backend", "intel-sycl"}, {"activeModel", "local-qwen"}, {"port", 8080}}), "valid settings rejected");
        AppSettings reopened;
        require(reopened.values()["backend"] == "intel-sycl" && reopened.values()["activeModel"] == "local-qwen", "settings not persisted");
        rag::RagController rag;
        require(waitUntil([&] { return rag.ready() && !rag.busy(); }), "RAG cannot browse without model weights");
        rag.refresh();
        require(waitUntil([&] { return !rag.busy(); }), "browse never completed");
        bool received = false;
        QObject::connect(&rag, &rag::RagController::agentSearchFinished, &app, [&](const QString &id, const QString &result) {
            require(id == "test-search", "search request id lost");
            require(result.contains("false"), "missing model search should fail");
            received = true;
        });
        rag.searchForAgent("test-search", "test");
        rag.reloadStats(); // A fast completion must not decrement a slow job's counter.
        require(waitUntil([&] { return received && !rag.busy() && !rag.working(); }), "agent search failed to finish");
        StreamQueue queue;
        FlmGateway gateway(queue, "127.0.0.1", 52625);
        ChatEngine chat(queue, gateway);
        chat.attachServices(&rag, &settings);
        QQmlApplicationEngine qml;
        qml.rootContext()->setContextProperty("rag", &rag);
        qml.rootContext()->setContextProperty("chatEngine", &chat);
        qml.rootContext()->setContextProperty("appSettings", &settings);
        QFile kinds(":/config/kinds.json");
        require(kinds.open(QIODevice::ReadOnly), "kind config resource missing");
        qml.rootContext()->setContextProperty("kindConfig", QJsonDocument::fromJson(kinds.readAll()).toVariant());
        qml.load(QUrl("qrc:/qml/Main.qml"));
        require(!qml.rootObjects().isEmpty(), "QML failed to load");
        auto *root = qml.rootObjects().first();
        auto *window = qobject_cast<QQuickWindow *>(root);
        require(window, "overlay is not a window");
        window->resize(1280, 900);
        require(QMetaObject::invokeMethod(root, "openChatUi"), "overlay cannot open");
        auto *panel = root->findChild<QObject *>("settingsPanel");
        require(panel, "settings panel missing");
        require(panel->setProperty("expanded", true), "settings panel cannot open");
        require(QMetaObject::invokeMethod(panel, "load"), "settings fields cannot load");
        QElapsedTimer render; render.start();
        require(waitUntil([&] { return render.elapsed() > 350; }), "render timeout");
        if (const QString image = qEnvironmentVariable("WATCHER_QA_IMAGE"); !image.isEmpty())
            require(window->grabWindow().save(image), "could not save UI verification image");
        chat.cancelActive();
        std::cout << "Settings persistence/validation, model-free browsing, async search and QML startup passed\n";
    } catch (const std::exception &error) { std::cerr << error.what() << '\n'; return 1; }
}
